from piskvorky import piskvorky1D

piskvorky1D()